//Steven Watson
//CS 1400
//Assignment 1
//February 6th, 2021

public class HelloWorld
{
    public static void main(String[] args)
    {
        System.out.println("Hello World, my name is Steven, and I like trains.\nI have been programming for 4 years.");
    }
}