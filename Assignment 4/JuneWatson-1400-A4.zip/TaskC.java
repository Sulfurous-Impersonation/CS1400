//Steven Watson
//CS 1400
//Assignment 4
//March 8th, 2021

public class TaskC 
{
    public static void main(String[] args)
    {
        for(int i = 5; i > 0; i--)
        {
            for(int j = i; j > 0; j--)
                System.out.print(":-)");
            System.out.println("");
        }
    }
}